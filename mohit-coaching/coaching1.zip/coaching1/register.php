<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "mohit_coaching0");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate and sanitize inputs
    $name = mysqli_real_escape_string($conn, trim($_POST['name']));
    $email = mysqli_real_escape_string($conn, trim($_POST['email']));
    $phone = mysqli_real_escape_string($conn, trim($_POST['phone']));
    $class = mysqli_real_escape_string($conn, $_POST['class']);
    
    // Validate phone number (10 digits)
    if (!preg_match('/^[0-9]{10}$/', $phone)) {
        $message = "<p style='color: red; text-align: center;'>Please enter a valid 10-digit phone number.</p>";
    } else {
        // Process subjects
        $subjects = '';
        if (isset($_POST['subjects']) && is_array($_POST['subjects'])) {
            $subjects = mysqli_real_escape_string($conn, implode(", ", $_POST['subjects']));
        }
        
        // Check if table exists
        $tableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'registrations'");
        
        if (mysqli_num_rows($tableCheck) == 0) {
            // Create table if it doesn't exist
            $createTableSQL = "CREATE TABLE registrations (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                email VARCHAR(255) NOT NULL,
                phone VARCHAR(15) NOT NULL,
                class VARCHAR(50) NOT NULL,
                subjects TEXT,
                registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )";
            
            if (!mysqli_query($conn, $createTableSQL)) {
                $message = "<p style='color: red; text-align: center;'>Error creating table: " . mysqli_error($conn) . "</p>";
                mysqli_close($conn);
                exit;
            }
        } else {
            // Check if phone column exists in existing table
            $columnCheck = mysqli_query($conn, "SHOW COLUMNS FROM registrations LIKE 'phone'");
            if (mysqli_num_rows($columnCheck) == 0) {
                // Add phone column if it doesn't exist
                $alterSQL = "ALTER TABLE registrations ADD COLUMN phone VARCHAR(15) NOT NULL AFTER email";
                if (!mysqli_query($conn, $alterSQL)) {
                    $message = "<p style='color: red; text-align: center;'>Error adding phone column: " . mysqli_error($conn) . "</p>";
                    mysqli_close($conn);
                    exit;
                }
            }
        }
        
        // Insert registration data
        $query = "INSERT INTO registrations (name, email, phone, class, subjects) 
                 VALUES ('$name', '$email', '$phone', '$class', '$subjects')";
        
        if (mysqli_query($conn, $query)) {
            $message = "<p style='color: green; text-align: center;'>Registration successful! Redirecting to homepage...</p>";
            echo '<meta http-equiv="refresh" content="2;url=index.php">';
        } else {
            $message = "<p style='color: red; text-align: center;'>Error: " . mysqli_error($conn) . "</p>";
        }
    }
}
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mohit Coaching Centre - Register</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
</head>
<body>
    <header>
       <nav>
    <div class="logo-container">
        <svg class="mc-logo" width="50" height="50" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
            <circle cx="50" cy="50" r="45" fill="#0033a0"/>
            <text x="50" y="65" font-family="Roboto, sans-serif" font-size="40" font-weight="700" fill="#ffd700" text-anchor="middle">MC</text>
            <circle cx="50" cy="50" r="45" fill="none" stroke="#ffd700" stroke-width="5"/>
        </svg>
        <div class="logo">Mohit Coaching Centre</div>
    </div>
    <button class="hamburger">☰</button>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="classes.php">Classes</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="register.php">Register</a></li>
        <?php if (isset($_SESSION['user_id'])): ?>
            <!-- Add logout link here if needed -->
        <?php else: ?>
            <!-- Add login link here if needed -->
        <?php endif; ?>
    </ul>
</nav>
    </header>

    <section id="register">
        <h2>Register for Classes</h2>
        <?php echo $message; ?>
        <form action="register.php" method="POST" onsubmit="return validateForm()">
            <input type="text" name="name" placeholder="Your Full Name" required minlength="3">
            <input type="email" name="email" placeholder="Your Email Address" required>
            <input type="tel" name="phone" placeholder="Your Phone Number (10 digits)" required pattern="[0-9]{10}" maxlength="10" title="Please enter a 10-digit phone number">
            
            <select name="class" required>
                <option value="" disabled selected>Select Class</option>
                <option value="6th">6th</option>
                <option value="7th">7th</option>
                <option value="8th">8th</option>
                <option value="9th">9th</option>
                <option value="10th">10th</option>
                <option value="11th Commerce">11th Commerce</option>
                <option value="11th Science">11th Science</option>
                <option value="12th Commerce">12th Commerce</option>
                <option value="12th Science">12th Science</option>
                <option value="12th Accounting">12th Accounting</option>
            </select>
            
            <div class="subjects-section">
                <label>Subjects (Select at least one):</label><br>
                <div class="checkbox-group">
                    <label><input type="checkbox" name="subjects[]" value="Science"> Science</label>
                    <label><input type="checkbox" name="subjects[]" value="Math"> Math</label>
                    <label><input type="checkbox" name="subjects[]" value="Economics"> Economics</label>
                    <label><input type="checkbox" name="subjects[]" value="Chemistry"> Chemistry</label>
                    <label><input type="checkbox" name="subjects[]" value="Biology"> Biology</label>
                    <label><input type="checkbox" name="subjects[]" value="Accounting"> Accounting</label>
                </div>
            </div>
            
            <button type="submit" class="btn">Register Now</button>
        </form>
    </section>

    <footer>
        <p>© 2025 Mohit Coaching Centre. All Rights Reserved.</p>
    </footer>

    <script>
    // Form validation
    function validateForm() {
        var name = document.forms[0]['name'].value;
        var email = document.forms[0]['email'].value;
        var phone = document.forms[0]['phone'].value;
        var classSelect = document.forms[0]['class'].value;
        var subjects = document.querySelectorAll('input[name="subjects[]"]:checked');
        
        // Name validation
        if (name.length < 3) {
            alert('Name must be at least 3 characters long.');
            return false;
        }
        
        // Email validation
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            alert('Please enter a valid email address.');
            return false;
        }
        
        // Phone validation
        var phoneRegex = /^[0-9]{10}$/;
        if (!phoneRegex.test(phone)) {
            alert('Please enter a valid 10-digit phone number.');
            return false;
        }
        
        // Class validation
        if (classSelect === '') {
            alert('Please select a class.');
            return false;
        }
        
        // Subjects validation
        if (subjects.length === 0) {
            alert('Please select at least one subject.');
            return false;
        }
        
        return true;
    }
    
    // Mobile navigation toggle
    document.querySelector('.hamburger').addEventListener('click', function() {
        document.querySelector('nav ul').classList.toggle('active');
    });
    
    // Auto-format phone number
    document.querySelector('input[name="phone"]').addEventListener('input', function(e) {
        this.value = this.value.replace(/\D/g, '').substring(0, 10);
    });
    </script>
</body>
</html>