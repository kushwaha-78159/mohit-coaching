<?php
include("config.php")
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mohit Coaching Centre - About Us</title>
    <link rel="stylesheet" href="styles.css?v=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <nav>
            <div class="logo-container">
                 <svg class="mc-logo" width="50" height="50" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="50" cy="50" r="45" fill="#0033a0"/>
                    <text x="52" y="37" font-family="Roboto, sans-serif" font-size="20" font-weight="700" fill="#ffd700" text-anchor="middle">Mohit</text>
                    <text x="50" y="57" font-family="Roboto, sans-serif" font-size="18" font-weight="700" fill="#ffd700" text-anchor="middle">Coaching</text>
                    <text x="49" y="78" font-family="Roboto, sans-serif" font-size="20" font-weight="700" fill="#ffd700" text-anchor="middle">Center</text>
                    <circle cx="50" cy="50" r="45" fill="none" stroke="#ffd700" stroke-width="5"/>
                </svg>
                <div class="logo">Mohit Coaching Centre</div>
            </div>
            <button class="hamburger">☰</button>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="classes.php">Classes</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="register.php">Register</a></li>
                <?php if (isset($_SESSION['user_id'])): ?>
                <?php else: ?>
                <?php endif; ?>
            </ul>
        </nav>
    </header>

    <div class="page-content">
        <section id="about">
            <h2>About Us</h2>
            <p>Mohit Coaching Centre, located in Faridabad, Haryana, is Haryana’s premier coaching institute dedicated to helping students from 6th to 12th grade achieve academic excellence.</p>
            <h3>About Coaching</h3>
            <p>Founded with a mission to redefine education, Mohit Coaching Centre offers a dynamic learning environment that combines academic rigor with personal growth. Our expert faculty, innovative teaching techniques, and small batch sizes ensure personalized attention for each student. With a focus on Science, Mathematics, Commerce, and Accounting, we provide comprehensive coaching for all classes. Boasting exceptional results, modern facilities, and a commitment to holistic development, we are the top choice for students and parents across Haryana.</p>
            
                <div class="faculty-card">
                    <img src="image/sir1.png" alt="Faculty 1">
                    <h4>Our Expert Faculty</h4>
                </div>
                <div class="faculty-card">
                    <img src="image/sir2.jpg" alt="Faculty 2">
                    <h4>Our Expert Faculty</h4>
                </div>
                <div class="faculty-card">
                    <img src="image/sir9.jpg" alt="Faculty 2">
                    <h4>Our Expert Faculty</h4>
                </div>
                <div class="faculty-card">
                    <img src="image/3.jpg" alt="Faculty 2">
                    <h4>Our Expert Faculty</h4>
                </div>
                
                <div class="faculty-card">
                    <img src="image/sir3.jpg" alt="Faculty 3">
                    <h4>Our Expert Faculty</h4>
                </div>
                <div class="faculty-card">
                    <img src="image/sir4.jpg" alt="Faculty 4">
                    <h4>Our Expert Faculty</h4>
                </div>
                <div class="faculty-card">
                    <img src="image/sir5.jpg" alt="Faculty 5">
                    <h4>Our Expert Faculty</h4>
                </div>
            </div>
        </section>
    </div>

    <footer>
        <p>© 2025 Mohit Coaching Centre. All Rights Reserved.</p>
    </footer>

    <script src="script.js?v=1.0"></script>
</body>
</html>