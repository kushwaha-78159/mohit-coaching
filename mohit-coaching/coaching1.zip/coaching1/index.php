<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "mohit_coaching0");
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mohit Coaching Centre - Home</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <nav>
            <div class="logo-container">
                <svg class="mc-logo" width="50" height="50" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="50" cy="50" r="45" fill="#0033a0"/>
                    <text x="50" y="65" font-family="Roboto, sans-serif" font-size="40" font-weight="700" fill="#ffd700" text-anchor="middle">MC</text>
                    <circle cx="50" cy="50" r="45" fill="none" stroke="#ffd700" stroke-width="5"/>
                </svg>
                <div class="logo">Mohit Coaching Centre</div>
            </div>
            <button class="hamburger">☰</button>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="classes.php">Classes</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="register.php">Register</a></li>
                <?php if (isset($_SESSION['user_id'])): ?>
                <?php else: ?>
                <?php endif; ?>
            </ul>
        </nav>
    </header>

    <section id="home">
        <div class="hero">
            <h1>Welcome to Mohit Coaching Centre</h1>
            <p>Your Path to Academic Excellence in Faridabad, Haryana</p>
            <a href="register.php" class="btn">Join Now</a>
        </div>
    </section>

    <section id="why-choose-us">
        <h2>Why Choose Us?</h2>
        <p>At Mohit Coaching Centre, we pride ourselves on delivering exceptional education with a focus on personalized learning, experienced faculty, and proven results.</p>
        <p>Our state-of-the-art facilities, small batch sizes, and innovative teaching methods ensure every student achieves their full potential. From 6th to 12th grade, we offer specialized coaching in Science, Mathematics, Commerce, and Accounting.</p>
    </section>

    <section class="bottom-image-section">
        <h3>Our Expert Faculty</h3>
        <div class="bottom-image-container">
            <div class="bottom-image-card">
                <img src="image/sir1.png" alt="Expert Faculty 1">
                <h4>Expert Faculty</h4>
            </div>
            <div class="bottom-image-card">
                <img src="image/sir2.jpg" alt="Expert Faculty 2">
                <h4>Expert Faculty</h4>
            </div>
        </div>
    </section>

    <footer>
        <p>© 2025 Mohit Coaching Centre. All Rights Reserved.</p>
    </footer>

    <script src="script.js"></script>
</body>
</html>