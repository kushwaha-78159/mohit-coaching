<?php
session_start();
require_once 'db_connect.php';


if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit;
}

$registrations = [];
$query = "SELECT r.*, u.name as user_name FROM registrations r 
          LEFT JOIN users u ON r.user_id = u.id 
          ORDER BY r.registration_date DESC";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $registrations[] = $row;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - Registrations</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Student Registrations</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Class</th>
            <th>Subjects</th>
            <th>Date</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($registrations as $reg): ?>
        <tr>
            <td><?= $reg['id'] ?></td>
            <td><?= htmlspecialchars($reg['name']) ?></td>
            <td><?= htmlspecialchars($reg['email']) ?></td>
            <td><?= htmlspecialchars($reg['class']) ?></td>
            <td><?= htmlspecialchars($reg['subjects']) ?></td>
            <td><?= $reg['registration_date'] ?></td>
            <td><?= ucfirst($reg['status']) ?></td>
            <td>
                <a href="approve_registration.php?id=<?= $reg['id'] ?>">Approve</a>
                <a href="reject_registration.php?id=<?= $reg['id'] ?>">Reject</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>