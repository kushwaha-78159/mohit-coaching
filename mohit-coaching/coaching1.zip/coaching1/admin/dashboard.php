<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Initialize messages
$success = '';
$error = '';

// Handle Delete Operations
if (isset($_GET['delete'])) {
    $table = $_GET['table'];
    $id = $_GET['id'];
    
    if ($table == 'users' && $id == 1) {
        $error = "Cannot delete the superadmin.";
    } else {
        $sql = "DELETE FROM $table WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            $success = "Record deleted successfully!";
            // Refresh to show changes
            header("Location: dashboard.php?success=delete");
            exit();
        } else {
            $error = "Error deleting record: " . $conn->error;
        }
    }
}

// Handle Update Operations
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    $table = $_POST['table'];
    $id = $_POST['id'];
    
    try {
        if ($table == 'users') {
            $stmt = $conn->prepare("UPDATE users SET name=?, email=?, role=? WHERE id=?");
            $stmt->bind_param("sssi", $_POST['name'], $_POST['email'], $_POST['role'], $id);
        } 
        elseif ($table == 'registrations') {
            $stmt = $conn->prepare("UPDATE registrations SET name=?, email=?, class=?, subjects=? WHERE id=?");
            $stmt->bind_param("ssssi", $_POST['name'], $_POST['email'], $_POST['class'], $_POST['subjects'], $id);
        } 
        elseif ($table == 'contact_messages') {
            $stmt = $conn->prepare("UPDATE contact_messages SET name=?, email=?, message=? WHERE id=?");
            $stmt->bind_param("sssi", $_POST['name'], $_POST['email'], $_POST['message'], $id);
        } 
        elseif ($table == 'payments') {
            $stmt = $conn->prepare("UPDATE payments SET registration_id=?, amount=?, payment_method=?, transaction_id=?, status=? WHERE id=?");
            $stmt->bind_param("idsssi", $_POST['registration_id'], $_POST['amount'], $_POST['payment_method'], $_POST['transaction_id'], $_POST['status'], $id);
        }

        if ($stmt->execute()) {
            $success = "Record updated successfully!";
            header("Location: dashboard.php?success=update");
            exit();
        } else {
            $error = "Error updating record: " . $conn->error;
        }
    } catch (Exception $e) {
        $error = "Database error: " . $e->getMessage();
    }
}


// Handle success messages from redirect
if (isset($_GET['success'])) {
    if ($_GET['success'] == 'update') {
        $success = "Record updated successfully!";
    } elseif ($_GET['success'] == 'delete') {
        $success = "Record deleted successfully!";
    }
}

// Fetch all data
$tables = ['users', 'registrations', 'contact_messages', 'payments'];
$data = [];

foreach ($tables as $table) {
    $result = $conn->query("SELECT * FROM $table");
    if ($result) {
        $data[$table] = $result->fetch_all(MYSQLI_ASSOC);
    } else {
        $data[$table] = [];
        $error = "Error fetching $table: " . $conn->error;
    }
}

// Assign to variables for easier access in HTML
$users = $data['users'];
$registrations = $data['registrations'];
$contact_messages = $data['contact_messages'];
$payments = $data['payments'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            box-shadow: 0 0.15rem 1.75rem 0 rgba(33, 40, 50, 0.15);
            margin-bottom: 2rem;
        }
        .card-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid rgba(0, 0, 0, 0.125);
        }
        .table-responsive {
            overflow-x: auto;
        }
        .badge {
            font-size: 0.85em;
            font-weight: 500;
        }
        .modal-content {
            border: none;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        }
    </style>
</head>
<body>
    <div class="container-fluid py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0 text-gray-800">Admin Dashboard</h1>
            <div>
                <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION['admin_name']); ?></span>
                <a href="logout.php" class="btn btn-danger btn-sm">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo $success; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <?php echo $error; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="row">
            <!-- Stats Cards -->
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                    Users</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo count($users); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-users fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-success shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                    Registrations</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo count($registrations); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-info shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                    Messages</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo count($contact_messages); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-envelope fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-warning shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                    Payments</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo count($payments); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Users Table -->
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-primary">Users</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?php echo $user['id']; ?></td>
                                <td><?php echo htmlspecialchars($user['name']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td>
                                    <span class="badge 
                                        <?php echo $user['role'] == 'admin' ? 'bg-primary' : 
                                              ($user['role'] == 'superadmin' ? 'bg-success' : 'bg-secondary'); ?>">
                                        <?php echo ucfirst($user['role']); ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editUserModal<?php echo $user['id']; ?>">
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                    <?php if ($user['id'] != 1): ?>
                                    <a href="?delete=1&table=users&id=<?php echo $user['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this user?')">
                                        <i class="fas fa-trash"></i> Delete
                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            
                            <!-- Edit User Modal -->
                            <div class="modal fade" id="editUserModal<?php echo $user['id']; ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header bg-primary text-white">
                                            <h5 class="modal-title">Edit User</h5>
                                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form method="POST" action="">
                                                <input type="hidden" name="table" value="users">
                                                <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                                                <div class="mb-3">
                                                    <label class="form-label">Name</label>
                                                    <input type="text" class="form-control" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Email</label>
                                                    <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Role</label>
                                                    <select class="form-select" name="role">
                                                        <option value="user" <?php echo $user['role'] == 'user' ? 'selected' : ''; ?>>User</option>
                                                        <option value="admin" <?php echo $user['role'] == 'admin' ? 'selected' : ''; ?>>Admin</option>
                                                        <option value="superadmin" <?php echo $user['role'] == 'superadmin' ? 'selected' : ''; ?>>Superadmin</option>
                                                    </select>
                                                </div>
                                                <button type="submit" name="update" class="btn btn-primary">Update</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        
        <!-- Registrations Table -->
<div class="card shadow mb-4">
    <div class="card-header py-3 d-flex justify-content-between align-items-center">
        <h6 class="m-0 font-weight-bold text-primary">Registrations</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Class</th>
                        <th>Subjects</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($registrations as $reg): ?>
                    <tr>
                        <td><?php echo $reg['id']; ?></td>
                        <td><?php echo htmlspecialchars($reg['name']); ?></td>
                        <td><?php echo htmlspecialchars($reg['email']); ?></td>
                        <td>
                            <?php 
                            // Check if phone column exists and display it
                            if(isset($reg['phone'])) {
                                echo htmlspecialchars($reg['phone']);
                            } elseif(isset($reg['phone_number'])) {
                                echo htmlspecialchars($reg['phone_number']);
                            } else {
                                echo 'N/A';
                            }
                            ?>
                        </td>
                        <td><?php echo htmlspecialchars($reg['class']); ?></td>
                        <td><?php echo htmlspecialchars($reg['subjects']); ?></td>
                        <td>
                            <?php 
                            if(isset($reg['registration_date'])) {
                                echo date('M d, Y', strtotime($reg['registration_date']));
                            } elseif(isset($reg['created_at'])) {
                                echo date('M d, Y', strtotime($reg['created_at']));
                            } else {
                                echo 'N/A';
                            }
                            ?>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editRegModal<?php echo $reg['id']; ?>">
                                <i class="fas fa-edit"></i> Edit
                            </button>
                            <a href="?delete=1&table=registrations&id=<?php echo $reg['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this registration?')">
                                <i class="fas fa-trash"></i> Delete
                            </a>
                        </td>
                    </tr>
                    
                    <!-- Edit Registration Modal -->
                    <div class="modal fade" id="editRegModal<?php echo $reg['id']; ?>" tabindex="-1">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header bg-primary text-white">
                                    <h5 class="modal-title">Edit Registration</h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <form method="POST" action="">
                                        <input type="hidden" name="table" value="registrations">
                                        <input type="hidden" name="id" value="<?php echo $reg['id']; ?>">
                                        <div class="mb-3">
                                            <label class="form-label">Name</label>
                                            <input type="text" class="form-control" name="name" value="<?php echo htmlspecialchars($reg['name']); ?>" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Email</label>
                                            <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($reg['email']); ?>" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Phone</label>
                                            <input type="text" class="form-control" name="phone" value="<?php 
                                                if(isset($reg['phone'])) {
                                                    echo htmlspecialchars($reg['phone']);
                                                } elseif(isset($reg['phone_number'])) {
                                                    echo htmlspecialchars($reg['phone_number']);
                                                }
                                            ?>" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Class</label>
                                            <input type="text" class="form-control" name="class" value="<?php echo htmlspecialchars($reg['class']); ?>" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Subjects</label>
                                            <input type="text" class="form-control" name="subjects" value="<?php echo htmlspecialchars($reg['subjects']); ?>" required>
                                        </div>
                                        <button type="submit" name="update" class="btn btn-primary">Update</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

        <!-- Contact Messages Table -->
<div class="card shadow mb-4">
    <div class="card-header py-3 d-flex justify-content-between align-items-center">
        <h6 class="m-0 font-weight-bold text-primary">Contact Messages</h6>
        <span class="badge bg-primary"><?php echo count($contact_messages); ?> messages</span>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Message</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($contact_messages as $msg): ?>
                    <tr>
                        <td><?php echo $msg['id']; ?></td>
                        <td><?php echo htmlspecialchars($msg['name']); ?></td>
                        <td><?php echo htmlspecialchars($msg['email']); ?></td>
                        <td>
                            <?php 
                            if(isset($msg['phone']) && !empty($msg['phone'])) {
                                echo htmlspecialchars($msg['phone']);
                            } else {
                                echo '<span class="text-muted">N/A</span>';
                            }
                            ?>
                        </td>
                        <td>
                            <?php 
                            $message_preview = htmlspecialchars($msg['message']);
                            if(strlen($message_preview) > 50) {
                                echo substr($message_preview, 0, 50) . '...';
                            } else {
                                echo $message_preview;
                            }
                            ?>
                        </td>
                        <td><?php echo date('M d, Y', strtotime($msg['created_at'])); ?></td>
                        <td>
                            <button class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#viewMsgModal<?php echo $msg['id']; ?>">
                                <i class="fas fa-eye"></i> View
                            </button>
                            <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editMsgModal<?php echo $msg['id']; ?>">
                                <i class="fas fa-edit"></i> Edit
                            </button>
                            <a href="?delete=1&table=contact_messages&id=<?php echo $msg['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this message?')">
                                <i class="fas fa-trash"></i> Delete
                            </a>
                        </td>
                    </tr>
                    
                    <!-- View Full Message Modal -->
                    <div class="modal fade" id="viewMsgModal<?php echo $msg['id']; ?>" tabindex="-1">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header bg-info text-white">
                                    <h5 class="modal-title">Message Details #<?php echo $msg['id']; ?></h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <strong>Name:</strong><br>
                                            <?php echo htmlspecialchars($msg['name']); ?>
                                        </div>
                                        <div class="col-md-4">
                                            <strong>Email:</strong><br>
                                            <a href="mailto:<?php echo htmlspecialchars($msg['email']); ?>">
                                                <?php echo htmlspecialchars($msg['email']); ?>
                                            </a>
                                        </div>
                                        <div class="col-md-4">
                                            <strong>Phone:</strong><br>
                                            <?php 
                                            if(isset($msg['phone']) && !empty($msg['phone'])) {
                                                echo '<a href="tel:' . htmlspecialchars($msg['phone']) . '">' . 
                                                     htmlspecialchars($msg['phone']) . '</a>';
                                            } else {
                                                echo 'N/A';
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12">
                                            <strong>Message:</strong><br>
                                            <div class="p-3 bg-light rounded">
                                                <?php echo nl2br(htmlspecialchars($msg['message'])); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mt-3">
                                        <div class="col-12">
                                            <strong>Received:</strong> 
                                            <?php echo date('F j, Y, g:i a', strtotime($msg['created_at'])); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <a href="mailto:<?php echo htmlspecialchars($msg['email']); ?>" class="btn btn-primary">
                                        <i class="fas fa-reply"></i> Reply
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Edit Message Modal -->
                    <div class="modal fade" id="editMsgModal<?php echo $msg['id']; ?>" tabindex="-1">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header bg-primary text-white">
                                    <h5 class="modal-title">Edit Message #<?php echo $msg['id']; ?></h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <form method="POST" action="">
                                        <input type="hidden" name="table" value="contact_messages">
                                        <input type="hidden" name="id" value="<?php echo $msg['id']; ?>">
                                        
                                        <div class="row">
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label">Name</label>
                                                <input type="text" class="form-control" name="name" 
                                                       value="<?php echo htmlspecialchars($msg['name']); ?>" required>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label">Email</label>
                                                <input type="email" class="form-control" name="email" 
                                                       value="<?php echo htmlspecialchars($msg['email']); ?>" required>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label">Phone</label>
                                                <input type="text" class="form-control" name="phone" 
                                                       value="<?php 
                                                       if(isset($msg['phone'])) {
                                                           echo htmlspecialchars($msg['phone']);
                                                       } else {
                                                           echo '';
                                                       }
                                                       ?>">
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label">Date</label>
                                                <input type="text" class="form-control" 
                                                       value="<?php echo date('M d, Y', strtotime($msg['created_at'])); ?>" readonly>
                                            </div>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label class="form-label">Message</label>
                                            <textarea class="form-control" name="message" rows="5" required><?php echo htmlspecialchars($msg['message']); ?></textarea>
                                        </div>
                                        
                                        <div class="d-flex justify-content-between">
                                            <button type="submit" name="update" class="btn btn-primary">
                                                <i class="fas fa-save"></i> Update
                                            </button>
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                                <i class="fas fa-times"></i> Cancel
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <?php if(count($contact_messages) == 0): ?>
        <div class="alert alert-info">
            <i class="fas fa-info-circle"></i> No contact messages found.
        </div>
        <?php endif; ?>
    </div>
</div>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Payments Table -->
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-primary">Payments</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Reg ID</th>
                                <th>Amount</th>
                                <th>Date</th>
                                <th>Method</th>
                                <th>Transaction ID</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($payments as $payment): ?>
                            <tr>
                                <td><?php echo $payment['id']; ?></td>
                                <td><?php echo $payment['registration_id']; ?></td>
                                <td>$<?php echo number_format($payment['amount'], 2); ?></td>
                                <td><?php echo date('M d, Y', strtotime($payment['payment_date'])); ?></td>
                                <td><?php echo htmlspecialchars($payment['payment_method']); ?></td>
                                <td><?php echo htmlspecialchars($payment['transaction_id']); ?></td>
                                <td>
                                    <span class="badge 
                                        <?php echo $payment['status'] == 'completed' ? 'bg-success' : 
                                              ($payment['status'] == 'pending' ? 'bg-warning' : 'bg-danger'); ?>">
                                        <?php echo ucfirst($payment['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editPaymentModal<?php echo $payment['id']; ?>">
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                    <a href="?delete=1&table=payments&id=<?php echo $payment['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this payment?')">
                                        <i class="fas fa-trash"></i> Delete
                                    </a>
                                </td>
                            </tr>
                            
                            <!-- Edit Payment Modal -->
                            <div class="modal fade" id="editPaymentModal<?php echo $payment['id']; ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header bg-primary text-white">
                                            <h5 class="modal-title">Edit Payment</h5>
                                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form method="POST" action="">
                                                <input type="hidden" name="table" value="payments">
                                                <input type="hidden" name="id" value="<?php echo $payment['id']; ?>">
                                                <div class="mb-3">
                                                    <label class="form-label">Registration ID</label>
                                                    <input type="number" class="form-control" name="registration_id" value="<?php echo $payment['registration_id']; ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Amount</label>
                                                    <input type="number" step="0.01" class="form-control" name="amount" value="<?php echo $payment['amount']; ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Payment Method</label>
                                                    <input type="text" class="form-control" name="payment_method" value="<?php echo htmlspecialchars($payment['payment_method']); ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Transaction ID</label>
                                                    <input type="text" class="form-control" name="transaction_id" value="<?php echo htmlspecialchars($payment['transaction_id']); ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Status</label>
                                                    <select class="form-select" name="status">
                                                        <option value="pending" <?php echo $payment['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                                        <option value="completed" <?php echo $payment['status'] == 'completed' ? 'selected' : ''; ?>>Completed</option>
                                                        <option value="failed" <?php echo $payment['status'] == 'failed' ? 'selected' : ''; ?>>Failed</option>
                                                    </select>
                                                </div>
                                                <button type="submit" name="update" class="btn btn-primary">Update</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-close alerts after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(function() {
                var alerts = document.querySelectorAll('.alert');
                alerts.forEach(function(alert) {
                    var bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                });
            }, 5000);
        });
    </script>
</body>
</html>
