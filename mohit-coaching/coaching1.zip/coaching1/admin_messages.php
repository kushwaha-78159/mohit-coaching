<?php
session_start();
require_once 'db_connect.php';

// एडमिन चेक
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit;
}

// मैसेजेस फेच करें
$messages = [];
$query = "SELECT * FROM contact_messages ORDER BY created_at DESC";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $messages[] = $row;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - Contact Messages</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Contact Messages</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Message</th>
            <th>Date</th>
            <th>Status</th>
        </tr>
        <?php foreach ($messages as $msg): ?>
        <tr>
            <td><?= $msg['id'] ?></td>
            <td><?= htmlspecialchars($msg['name']) ?></td>
            <td><?= htmlspecialchars($msg['email']) ?></td>
            <td><?= nl2br(htmlspecialchars($msg['message'])) ?></td>
            <td><?= $msg['created_at'] ?></td>
            <td><?= $msg['is_read'] ? 'Read' : 'Unread' ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>