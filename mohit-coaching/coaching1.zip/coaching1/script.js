document.addEventListener('DOMContentLoaded', () => {
    const navLinks = document.querySelectorAll('nav ul li a');
    const navUl = document.querySelector('nav ul');
    const hamburger = document.querySelector('.hamburger');

    // Toggle hamburger menu
    hamburger.addEventListener('click', () => {
        navUl.classList.toggle('active');
    });

    // Close menu when a link is clicked and show the selected page
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            const href = link.getAttribute('href');
            if (href.startsWith('#')) {
                e.preventDefault();
                const targetId = href.substring(1);
                const targetSection = document.getElementById(targetId);
                if (targetSection) {
                    // Hide all sections
                    document.querySelectorAll('section').forEach(section => {
                        section.style.display = 'none';
                    });
                    // Show the target section
                    targetSection.style.display = 'block';
                    window.scrollTo({
                        top: targetSection.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            }
            navUl.classList.remove('active'); // Close menu on link click
        });
    });
});