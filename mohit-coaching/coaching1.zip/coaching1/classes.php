<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "mohit_coaching0");
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mohit Coaching Centre - Classes</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <nav>
    <div class="logo-container">
        <svg class="mc-logo" width="50" height="50" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
            <circle cx="50" cy="50" r="45" fill="#0033a0"/>
            <text x="50" y="65" font-family="Roboto, sans-serif" font-size="40" font-weight="700" fill="#ffd700" text-anchor="middle">MC</text>
            <circle cx="50" cy="50" r="45" fill="none" stroke="#ffd700" stroke-width="5"/>
        </svg>
        <div class="logo">Mohit Coaching Centre</div>
    </div>
    <button class="hamburger">☰</button>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="classes.php">Classes</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="register.php">Register</a></li>
        <?php if (isset($_SESSION['user_id'])): ?>
            <!-- Add logout link here if needed -->
        <?php else: ?>
            <!-- Add login link here if needed -->
        <?php endif; ?>
    </ul>
</nav>
    </header>

    <section id="classes">
        <h2>Our Classes</h2>
        <p>We offer comprehensive coaching for students from 6th to 12th grade, covering Science, Mathematics, Commerce, and Accounting.</p>
        <div class="class-container">
            <div class="class-card">
                <img src="image/sir6.jpg" alt="Class 6th all subject">
                <h3>Class 6th all subject</h3>
                <p>Foundation course covering Science, Math, and English for young learners.</p>
            </div>
            <div class="class-card">
                <img src="image/sir7.jpg" alt="Class 7th all subject">
                <h3>Class 7th all subject</h3>
                <p>Strengthening core concepts in Science, Math, and Social Studies.</p>
            </div>
            <div class="class-card">
                <img src="image/sir8.jpg" alt="Class 8th all subject">
                <h3>Class 8th all subject</h3>
                <p>Advanced preparation for board-level Science and Math.</p>
            </div>
            <div class="class-card">
                <img src="image/sir4.jpg" alt="Class 9th">
                <h3>Class 9th</h3>
                <p>Focused coaching for Science, Math, and preparatory board exams.</p>
            </div>
            <div class="class-card">
                <img src="image/sir5.jpg" alt="Class 10th  science and math and english">
                <h3>Class 10th science and math and english</h3>
                <p>Intensive board exam preparation for Science, Math, and English.</p>
            </div>
            <div class="class-card">
                <img src="image/sir2.jpg" alt="Class 11th Commerce with eco">
                <h3>Class 11th Commerce with eco</h3>
                <p>Specialized coaching in Economics, Accounting, and Business Studies.</p>
            </div>
            <div class="class-card">
                <img src="image/sir1.png" alt="Class 11th science / phy and chem and bio ">
                <h3>Class 11th science / phy and chem and bio</h3>
                <p>In-depth coaching for Physics, Chemistry, and Biology/Math.</p>
            </div>
            <div class="class-card">
                <img src="image/sir3.jpg" alt="Class 11th commerce with math ">
                <h3>Class 11th commerce with math</h3>
                <p>Advanced preparation for board exams in Commerce subjects.</p>
            </div>
            <div class="class-card">
                <img src="image/sir1.png" alt="Class 12th Science">
                <h3>Class 12th Science</h3>
                <p>Rigorous coaching for board and competitive exams in Science.</p>
            </div>
            <div class="class-card">
                <img src="image/sir2.jpg" alt="Class 12th Accounting">
                <h3>Class 12th Accounting</h3>
                <p>Expert guidance for mastering Accounting and related subjects.</p>
            </div>
        </div>
    </section>

    <footer>
        <p>© 2025 Mohit Coaching Centre. All Rights Reserved.</p>
    </footer>

    <script src="script.js"></script>
</body>
</html>