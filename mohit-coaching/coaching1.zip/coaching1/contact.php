<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "mohit_coaching0");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if contact_messages table exists
    $check_table = mysqli_query($conn, "SHOW TABLES LIKE 'contact_messages'");
    if (mysqli_num_rows($check_table) == 0) {
        // Create table if it doesn't exist
        $create_table = "CREATE TABLE contact_messages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL,
            phone VARCHAR(20),
            message TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        
        if (mysqli_query($conn, $create_table)) {
            $message = "<p style='color: green; text-align: center;'>Table created. Please submit your message again.</p>";
        } else {
            $message = "<p style='color: red; text-align: center;'>Error creating table: " . mysqli_error($conn) . "</p>";
        }
    } else {
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $phone = mysqli_real_escape_string($conn, $_POST['phone']);
        $message_text = mysqli_real_escape_string($conn, $_POST['message']);
        
        // Check if phone column exists, if not add it
        $check_column = mysqli_query($conn, "SHOW COLUMNS FROM contact_messages LIKE 'phone'");
        if (mysqli_num_rows($check_column) == 0) {
            $alter_table = "ALTER TABLE contact_messages ADD COLUMN phone VARCHAR(20) AFTER email";
            mysqli_query($conn, $alter_table);
        }
        
        $query = "INSERT INTO contact_messages (name, email, phone, message) VALUES ('$name', '$email', '$phone', '$message_text')";
        if (mysqli_query($conn, $query)) {
            $message = "<p style='color: green; text-align: center;'>Message sent successfully!</p>";
            header("Refresh: 2; url=contact.php");
        } else {
            $message = "<p style='color: red; text-align: center;'>Error: " . mysqli_error($conn) . "</p>";
        }
    }
}
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mohit Coaching Centre - Contact</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <nav>
    <div class="logo-container">
        <svg class="mc-logo" width="50" height="50" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
            <circle cx="50" cy="50" r="45" fill="#0033a0"/>
            <text x="50" y="65" font-family="Roboto, sans-serif" font-size="40" font-weight="700" fill="#ffd700" text-anchor="middle">MC</text>
            <circle cx="50" cy="50" r="45" fill="none" stroke="#ffd700" stroke-width="5"/>
        </svg>
        <div class="logo">Mohit Coaching Centre</div>
    </div>
    <button class="hamburger">☰</button>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="classes.php">Classes</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="register.php">Register</a></li>
        <?php if (isset($_SESSION['user_id'])): ?>
            <!-- Add logout link here if needed -->
        <?php else: ?>
            <!-- Add login link here if needed -->
        <?php endif; ?>
    </ul>
</nav>
    </header>

    <section id="contact">
        <h2>Contact Us</h2>
        <p>Address: Jeevan Nagar Part 2, Faridabad, Gounnchi Lal Khoti, Haryana</p>
        <p>Email: contact@mohitcoaching.com</p>
        <p>Phone: +91-9876543210</p>
        <?php echo $message; ?>
        <form action="contact.php" method="POST">
            <input type="text" name="name" placeholder="Your Name" required>
            <input type="email" name="email" placeholder="Your Email" required>
            <input type="tel" name="phone" placeholder="Your Phone Number (e.g., +91-9876543210)" pattern="[\+0-9\s\-\(\)]{10,15}" title="Enter a valid phone number (10-15 digits)" required>
            <textarea name="message" placeholder="Your Message" required></textarea>
            <button type="submit" class="btn">Send Message</button>
        </form>
    </section>

    <footer>
        <p>© 2025 Mohit Coaching Centre. All Rights Reserved.</p>
    </footer>

    <script src="script.js"></script>
</body>
</html>